SHOP PIC - Version 1

Fonctions :
- Ajout d'images par bouton, maximum 10 images.
- Formats acceptes : JPG, JPEG, PNG.
- Limite : 5 Mo maximum par image.
- Image carree obligatoire, sinon refus.
- Export au choix : PrestaShop 800x800 ou Amazon 1200x1200.
- Conversion en JPG.
- Compression optimisee.
- Nettete legere appliquee.
- Suppression des metadonnees EXIF / appareil / geolocalisation.
- Dossier d'export choisi au premier lancement puis memorise.
- Blocage si un fichier du meme nom existe deja.
- Popup finale avec poids avant, poids apres et pourcentage de reduction.

Pour lancer en Python :
1. Installer Python 3.
2. Double-cliquer sur install_requirements.bat si vous en creez un, ou lancer : pip install -r requirements.txt
3. Lancer : python shop_pic_app.py

Pour generer le .EXE Windows :
1. Mettre tous les fichiers dans le meme dossier.
2. Double-cliquer sur build_shop_pic_exe.bat
3. Le fichier final sera dans le dossier dist : Shop Pic.exe

Note :
L'application est volontairement simple et locale. Aucune image n'est envoyee sur Internet.
