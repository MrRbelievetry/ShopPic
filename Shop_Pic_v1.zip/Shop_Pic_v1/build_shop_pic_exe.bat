@echo off
cd /d %~dp0
python -m pip install --upgrade pip
python -m pip install pillow pyinstaller
pyinstaller --noconfirm --onefile --windowed --name "Shop Pic" --icon "shop_pic.ico" --add-data "shop_pic.ico;." shop_pic_app.py
pause
